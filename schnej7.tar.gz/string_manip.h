/* JERRY SCHNEIDER */
char * findString( char * data, char * tag );
int endsWith( char * data, char * tag );
int beginsWith( char * data, char * tag );
char * getTagValue( char * data, char * tag );
char * getFirstWord( char * data );

